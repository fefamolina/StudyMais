let questions = [
    {
    numb: 1,
    question: "Qual das alternativas responde corretamente a pergunta “How are you?”",
    answer: "I am fine,thanks",
    options: [
      "I am Brazilian",
      "I am 10",
      "I am fine,thanks",
      "I am teacher"
    ]
  },
    {
    numb: 2,
    question: "O significado da frase “There are two books on the table.” é:",
    answer: "Há dois livros sobre a mesa",
    options: [
      "Há dois livros sobre a mesa",
      "Há dois livros aqui sob a mesa",
      "Há dois livros sob a mesa",
      "Há dois livros na mesa"
    ]
  },
    {
    numb: 3,
    question: "A palavra “actually” significa:",
    answer: "Na verdade",
    options: [
      "Verdadeiramente",
      "Atual",
      "Atualmente",
      "Na verdade"
    ]
  },
    {
    numb: 4,
    question: "Qual das opções abaixo completa corretamente a frase “She __________ work on weekends.”?",
    answer: "doesn't",
    options: [
      "isn't",
      "don't",
      "aren't",
      "doesn't"
    ]
  },
    {
    numb: 5,
    question: "Qual das frases completa o diálogo a seguir: Jerry: Mom, this is my friend John. Jerry’s mom: ______________",
    answer: "Nice to meeet you, John!",
    options: [
      "Nice to meeet you, John!",
      "See you tomorrow, John!",
      "What is your phone number, John?",
      "What's your name, John?"
    ]
  },
  
    {
    numb: 6,
    question: "Na frase “He goes to college every morning.”, a palavra “college” significa:",
    answer: "Faculdade",
    options: [
    "Colégio",
    "Faculdade",
    "Universidade",
    "Curso"
    ]
  },
    {
    numb: 7,
    question: "Qual das frases está correta?",
    answer: "He is always late.",
    options: [
    "He is always late.",
    "He is always is late.",
    "He always is late.",
    "He is late always."
    ]
  },
  {
    numb: 8,
    question: "Que tempo verbal está expresso na frase “They washed the dishes.”?",
    answer: "Simple Past.",
    options: [
    "Simple Present.",
    "Simple Past.",
    "Simple Future.",
    "Simple Passt."
    ]
  },
  {
    numb: 9,
    question: "Ao passar para a voz passiva a frase “Alice made Sally's birthday cake.”, teremos:",
    answer: "Sally's birthday cake was made by Alice.",
    options: [
    "Sally's birthday cake is made by Alice.",
    "Sally's birthday cake was made by Alice.",
    "Sally's birthday cake Alice made.",
    "Alice made the birthday cake for Sally."
    ]
  },
  {
    numb: 10,
    question: "Qual das frases abaixo indica tempo futuro?",
    answer: "Bob will be promoted.",
    options: [
    "Bob is going to school.",
    "Mike liked the cake.",
    "Bob will be promoted.",
    "Will plays the guitar."
    ]
  },
];
