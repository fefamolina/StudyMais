let questions = [
    {
    numb: 1,
    question: "Um dos objetos abaixo está com a grafia errada.",
    answer: "Bulhe de café",
    options: [
      "Panela de pressão",
      "Fogão a lenha",
      "Xícara de chá",
      "Bulhe de café"
    ]
  },
    {
    numb: 2,
    question: "A divisão silábica de uma das palavras abaixo está de forma errada.",
    answer: "Es-pi-ra-is",
    options: [
      "Ca-der-ne-ta",
      "Es-pi-ra-is",
      "Ma-ca-co",
      "Pa-ne-la"
    ]
  },
    {
    numb: 3,
    question: "Assinale a alternativa que contém erro de ortografia.",
    answer: "Esterilisar",
    options: [
      "Esterilisar",
      "Aborígine",
      "Irrequieto",
      "Detenção"
    ]
  },
    {
    numb: 4,
    question: "Uma das palavras abaixo não pertence ao gênero masculino.",
    answer: "Hora",
    options: [
      "Cruzador",
      "Dólar",
      "Hora",
      "Cristal"
    ]
  },
    {
    numb: 5,
    question: "Uma das palavras abaixo está grafada de forma incorreta.",
    answer: "Sobrehumano",
    options: [
      "Extra-humano",
      "Sobrehumano",
      "Coobrigação",
      "Pós-graduação"
    ]
  },
  
    {
    numb: 6,
    question: "Um dos grupos abaixo não obedece a sequência de gêneros: Masculino, Feminino, Feminino.",
    answer: "Jabuti, Caderno, Caneta",
    options: [
    "Camelo, Chave, Índia",
    "Chifre, Chita, Chamada",
    "Jabuti, Caderno, Caneta",
    " Caldo, Canela, Caneca"
    ]
  },
];
