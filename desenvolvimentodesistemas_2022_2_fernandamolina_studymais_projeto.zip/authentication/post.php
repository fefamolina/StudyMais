<?php 
      session_start();
      $conn = mysqli_connect("localhost" , "root" , "" , "authentication") or die("Connection Failed");
      
      
?>